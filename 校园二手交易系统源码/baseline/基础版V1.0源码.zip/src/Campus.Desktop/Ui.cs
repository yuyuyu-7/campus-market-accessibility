using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
namespace Campus.Desktop;
// 集中放置视图工厂；业务逻辑位于服务模块。
public static class Ui {
 public static TextBlock Text(string s,double size=16)=>new(){Text=s,FontSize=size,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,8)};
 public static Button Button(string text,Action action){var b=new Button{Content=text,Padding=new Thickness(14,8,14,8),Margin=new Thickness(0,4,8,4),MinHeight=36};b.Click+=(_,_)=>action();return b;}
 public static void Field(Panel panel,string label,Control input,string help=""){panel.Children.Add(Text(label));input.Margin=new Thickness(0,0,0,10);input.MinHeight=34;panel.Children.Add(input);if(help!="")panel.Children.Add(Text(help,13));}
 public static void Theme(Window w){w.FontFamily=new FontFamily("Microsoft YaHei UI");w.FontSize=16;w.SetResourceReference(Control.BackgroundProperty,SystemColors.WindowBrushKey);w.SetResourceReference(Control.ForegroundProperty,SystemColors.WindowTextBrushKey);}
 public static void Announce(TextBlock status,string message){status.Text=message;}
 public static void FocusFirst(FrameworkElement root) { }
}
public sealed class FormWindow:Window {
 public readonly StackPanel Fields=new();public readonly TextBlock Status=Ui.Text("");public readonly StackPanel Actions=new(){Orientation=Orientation.Horizontal};
 public FormWindow(Window owner,string title){Owner=owner;Title=title;Width=620;Height=680;MinWidth=480;MinHeight=420;WindowStartupLocation=WindowStartupLocation.CenterOwner;Ui.Theme(this);var root=new DockPanel{Margin=new Thickness(24)};var footer=new StackPanel();footer.Children.Add(Status);footer.Children.Add(Actions);DockPanel.SetDock(footer,Dock.Bottom);root.Children.Add(footer);root.Children.Add(new ScrollViewer{Content=Fields,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Focusable=false});Content=root;Actions.Children.Add(Ui.Button("关闭(_C)",Close));}
 public void Submit(string name,Func<Task> action){var b=Ui.Button(name,()=>{});b.IsDefault=true;b.Click+=async(_,_)=>{if(!b.IsEnabled)return;b.IsEnabled=false;try{await action();}catch(Exception e){Ui.Announce(Status,e.Message);}finally{b.IsEnabled=true;}};Actions.Children.Insert(0,b);}
 public void ShowOwned(){ShowDialog();}
}
